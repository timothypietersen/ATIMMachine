using System;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Data.SqlClient;

public class AccountManager
{
    // Method to register a new account
    public void RegisterAccount()
    {
        Console.WriteLine("\nRegistering a new account...");

        string newUsername;
        bool usernameExists;

        // Prompt the user to enter a new username and check for its existence
        do
        {
            Console.Write("Enter a new username: ");
            newUsername = Console.ReadLine();

            // Check if the username exists in the database
            usernameExists = UsernameExists(newUsername);

            if (usernameExists)
            {
                Console.WriteLine("\n❌ Username already exists. Please choose a different username.");
            }

        } while (usernameExists);  // Loop until a unique username is entered

        // If username is available, proceed to password entry
        Console.Write("Enter a new password: ");
        string newPassword = ReadPassword();

        // Simple CAPTCHA to prevent bot accounts
        if (!SolveCaptcha())
        {
            Console.WriteLine("\n❌ CAPTCHA failed! Registration aborted.");
            return;
        }

        // Hash the password before storing
        string hashedPassword = ComputeSha256Hash(newPassword);

        // Database connection string
        string connectionString = "Server=localhost;Database=ATMAppDB;Trusted_Connection=True;TrustServerCertificate=True;";

        // Insert new account details into the database
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();

            string insertSql = "INSERT INTO Customer (Username, PasswordHash) VALUES (@username, @passwordHash)";
            using (SqlCommand insertCmd = new SqlCommand(insertSql, conn))
            {
                insertCmd.Parameters.AddWithValue("@username", newUsername);
                insertCmd.Parameters.AddWithValue("@passwordHash", hashedPassword);

                insertCmd.ExecuteNonQuery();
                Console.WriteLine("\n✅ Account successfully created!");
            }
        }
    }

    // Method to check if the username already exists in the database
    private bool UsernameExists(string username)
    {
        string connectionString = "Server=localhost;Database=ATMAppDB;Trusted_Connection=True;TrustServerCertificate=True;";

        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();

            string checkUsernameSql = "SELECT COUNT(*) FROM Customer WHERE Username = @username";
            using (SqlCommand cmd = new SqlCommand(checkUsernameSql, conn))
            {
                cmd.Parameters.AddWithValue("@username", username);
                int count = (int)cmd.ExecuteScalar();
                return count > 0;
            }
        }
    }

    // Method to compute the SHA-256 hash of a password
    private string ComputeSha256Hash(string rawData)
    {
        using SHA256 sha256Hash = SHA256.Create();
        byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
        StringBuilder builder = new StringBuilder();
        foreach (byte b in bytes)
            builder.Append(b.ToString("x2"));
        return builder.ToString();
    }

    // Method to read a password securely (without showing characters in console)
    private string ReadPassword()
    {
        StringBuilder input = new StringBuilder();
        ConsoleKeyInfo key;
        do
        {
            key = Console.ReadKey(true);
            if (key.Key != ConsoleKey.Backspace && key.Key != ConsoleKey.Enter)
            {
                input.Append(key.KeyChar);
                Console.Write("*");
            }
            else if (key.Key == ConsoleKey.Backspace && input.Length > 0)
            {
                input.Remove(input.Length - 1, 1);
                Console.Write("\b \b");
            }
        } while (key.Key != ConsoleKey.Enter);
        return input.ToString();
    }

    // Method to solve a simple CAPTCHA
    private bool SolveCaptcha()
    {
        Random rand = new Random();
        int num1 = rand.Next(1, 10);
        int num2 = rand.Next(1, 10);
        int correctAnswer = num1 + num2;

        Console.WriteLine($"\n[CAPTCHA] What is {num1} + {num2}?");
        Console.Write("Your answer: ");
        string userAnswer = Console.ReadLine();

        if (int.TryParse(userAnswer, out int answer) && answer == correctAnswer)
        {
            Console.WriteLine("\n✅ CAPTCHA solved successfully!");
            return true;
        }
        else
        {
            Console.WriteLine("\n❌ Incorrect CAPTCHA answer.");
            return false;
        }
    }
}
