﻿using System;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Data.SqlClient;

class Program
{
    static void Main()
    {
        bool validLogin = false;

        while (!validLogin)
        {
            Console.Clear();
            Console.Write("Enter username: ");
            string username = Console.ReadLine();

            Console.Write("Enter password: ");
            string password = ReadPassword();

            string hashedPassword = ComputeSha256Hash(password);

            string connectionString = "Server=localhost;Database=ATMAppDB;Trusted_Connection=True;TrustServerCertificate=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string sql = "SELECT COUNT(*) FROM Customer WHERE Username = @username AND PasswordHash = @passwordHash";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@passwordHash", hashedPassword);

                    int count = (int)cmd.ExecuteScalar();

                    if (count > 0)
                    {
                        Console.WriteLine("\n✅ Login successful!");
                        validLogin = true;
                    }
                    else
                    {
                        Console.WriteLine("\n❌ Invalid username or password.");
                        Console.WriteLine("\nWould you like to try again? Yes (Y) / No (N)");

                        string response = Console.ReadLine().Trim().ToUpper();

                        if (response == "N")
                        {
                            Console.WriteLine("\nWould you like to register a new account? Yes (Y) / No (N)");

                            string registerResponse = Console.ReadLine().Trim().ToUpper();

                            if (registerResponse == "Y")
                            {
                                RegisterAccount();
                                validLogin = true; // Proceed after registration
                            }
                            else
                            {
                                Console.WriteLine("\nGoodbye!");
                                validLogin = true; // Exit loop
                            }
                        }
                    }
                }
            }
        }
    }

    static string ComputeSha256Hash(string rawData)
    {
        using SHA256 sha256Hash = SHA256.Create();
        byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
        StringBuilder builder = new StringBuilder();
        foreach (byte b in bytes)
            builder.Append(b.ToString("x2"));
        return builder.ToString();
    }

    static string ReadPassword()
    {
        StringBuilder input = new StringBuilder();
        ConsoleKeyInfo key;
        do
        {
            key = Console.ReadKey(true);
            if (key.Key != ConsoleKey.Backspace && key.Key != ConsoleKey.Enter)
            {
                input.Append(key.KeyChar);
                Console.Write("*");
            }
            else if (key.Key == ConsoleKey.Backspace && input.Length > 0)
            {
                input.Remove(input.Length - 1, 1);
                Console.Write("\b \b");
            }
        } while (key.Key != ConsoleKey.Enter);
        return input.ToString();
    }

    static void RegisterAccount()
    {
        Console.WriteLine("\nRegistering a new account...");

        Console.Write("Enter a new username: ");
        string newUsername = Console.ReadLine();

        Console.Write("Enter a new password: ");
        string newPassword = ReadPassword();

        // Simple CAPTCHA to prevent bot accounts
        if (!SolveCaptcha())
        {
            Console.WriteLine("\n❌ CAPTCHA failed! Registration aborted.");
            return;
        }

        string hashedPassword = ComputeSha256Hash(newPassword);

        string connectionString = "Server=localhost;Database=ATMAppDB;Trusted_Connection=True;TrustServerCertificate=True;";

        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();

            string checkUsernameSql = "SELECT COUNT(*) FROM Customer WHERE Username = @username";
            using (SqlCommand cmd = new SqlCommand(checkUsernameSql, conn))
            {
                cmd.Parameters.AddWithValue("@username", newUsername);
                int count = (int)cmd.ExecuteScalar();

                if (count > 0)
                {
                    Console.WriteLine("\n❌ Username already exists. Try a different username.");
                }
                else
                {
                    string insertSql = "INSERT INTO Customer (Username, PasswordHash) VALUES (@username, @passwordHash)";
                    using (SqlCommand insertCmd = new SqlCommand(insertSql, conn))
                    {
                        insertCmd.Parameters.AddWithValue("@username", newUsername);
                        insertCmd.Parameters.AddWithValue("@passwordHash", hashedPassword);

                        insertCmd.ExecuteNonQuery();
                        Console.WriteLine("\n✅ Account successfully created!");
                    }
                }
            }
        }
    }

    static bool SolveCaptcha()
    {
        Random rand = new Random();
        int num1 = rand.Next(1, 10);
        int num2 = rand.Next(1, 10);
        int correctAnswer = num1 + num2;

        Console.WriteLine($"\n[CAPTCHA] What is {num1} + {num2}?");
        Console.Write("Your answer: ");
        string userAnswer = Console.ReadLine();

        if (int.TryParse(userAnswer, out int answer) && answer == correctAnswer)
        {
            Console.WriteLine("\n✅ CAPTCHA solved successfully!");
            return true;
        }
        else
        {
            Console.WriteLine("\n❌ Incorrect CAPTCHA answer.");
            return false;
        }
    }
}
