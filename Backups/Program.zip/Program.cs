﻿using System;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Data.SqlClient;

class Program
{
    static void Main()
    {
        Console.Write("Enter username: ");
        string username = Console.ReadLine();

        Console.Write("Enter password: ");
        string password = ReadPassword();

        string hashedPassword = ComputeSha256Hash(password);

        // 🔍 DEBUG: Show the hashed password (remove after testing)
        Console.WriteLine($"\n[DEBUG] Hashed password: {hashedPassword}");

        string connectionString = "Server=localhost;Database=ATMAppDB;Trusted_Connection=True;TrustServerCertificate=True;";

        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            conn.Open();

            // 🔍 DEBUG: Check total users in DB (remove after testing)
            using (SqlCommand testCmd = new SqlCommand("SELECT COUNT(*) FROM Customer", conn))
            {
                int totalUsers = (int)testCmd.ExecuteScalar();
                Console.WriteLine($"[DEBUG] Total users in DB: {totalUsers}");
            }

            string sql = "SELECT COUNT(*) FROM Customer WHERE Username = @username AND PasswordHash = @passwordHash";

            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@passwordHash", hashedPassword);

                int count = (int)cmd.ExecuteScalar();

                // 🔍 DEBUG: Show matching count (remove after testing)
                Console.WriteLine($"[DEBUG] Matching records found: {count}");

                if (count > 0)
                    Console.WriteLine("\n✅ Login successful!");
                else
                    Console.WriteLine("\n❌ Invalid username or password.");
            }
        }
    }

    static string ComputeSha256Hash(string rawData)
    {
        using SHA256 sha256Hash = SHA256.Create();
        byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
        StringBuilder builder = new StringBuilder();
        foreach (byte b in bytes)
            builder.Append(b.ToString("x2"));
        return builder.ToString();
    }

    static string ReadPassword()
    {
        StringBuilder input = new StringBuilder();
        ConsoleKeyInfo key;
        do
        {
            key = Console.ReadKey(true);
            if (key.Key != ConsoleKey.Backspace && key.Key != ConsoleKey.Enter)
            {
                input.Append(key.KeyChar);
                Console.Write("*");
            }
            else if (key.Key == ConsoleKey.Backspace && input.Length > 0)
            {
                input.Remove(input.Length - 1, 1);
                Console.Write("\b \b");
            }
        } while (key.Key != ConsoleKey.Enter);
        return input.ToString();
    }
}
