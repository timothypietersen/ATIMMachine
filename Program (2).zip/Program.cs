﻿using System;
using Microsoft.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

class Program
{
    static void Main()
    {
        AccountManager accountManager = new AccountManager();

        bool validLogin = false;

        while (!validLogin)
        {
            // Clear the console for a fresh login prompt
            Console.Clear();
            
            // Display a simple DOS-like login screen
            Console.WriteLine("=========================================");
            Console.WriteLine("           ATM Login System              ");
            Console.WriteLine("=========================================");
            Console.WriteLine();
            Console.Write("Enter username: ");
            string username = Console.ReadLine()?.Trim();  // Ensure username is not null
            if (string.IsNullOrEmpty(username))
            {
                Console.WriteLine("Username cannot be empty.");
                continue;
            }

            Console.Write("Enter password: ");
            string password = ReadPassword();

            string hashedPassword = ComputeSha256Hash(password);

            string connectionString = "Server=localhost;Database=ATMAppDB;Trusted_Connection=True;TrustServerCertificate=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string sql = "SELECT COUNT(*) FROM Customer WHERE Username = @username AND PasswordHash = @passwordHash";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@passwordHash", hashedPassword);

                    int count = (int)cmd.ExecuteScalar();

                    if (count > 0)
                    {
                        Console.WriteLine("\n✅ Login successful!");
                        validLogin = true;
                    }
                    else
                    {
                        Console.WriteLine("\n❌ Invalid username or password.");
                        Console.WriteLine("\nWould you like to try again? Yes (Y) / No (N)");

                        string response = Console.ReadLine()?.Trim().ToUpper();

                        if (response == "N")
                        {
                            Console.WriteLine("\nWould you like to register a new account? Yes (Y) / No (N)");

                            string registerResponse = Console.ReadLine()?.Trim().ToUpper();

                            if (registerResponse == "Y")
                            {
                                accountManager.RegisterAccount(); // Correct call without parameters
                                validLogin = true; // Proceed after registration
                            }
                            else
                            {
                                Console.WriteLine("\nGoodbye!");
                                validLogin = true; // Exit loop
                            }
                        }
                    }
                }
            }
        }
    }

    // Method to compute the SHA-256 hash of a password
    static string ComputeSha256Hash(string rawData)
    {
        using (var sha256Hash = SHA256.Create())
        {
            byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
            var builder = new StringBuilder();
            foreach (var b in bytes)
                builder.Append(b.ToString("x2"));
            return builder.ToString();
        }
    }

    // Method to read a password securely (without showing characters in console)
    static string ReadPassword()
    {
        var input = new StringBuilder();
        ConsoleKeyInfo key;
        do
        {
            key = Console.ReadKey(true);
            if (key.Key != ConsoleKey.Backspace && key.Key != ConsoleKey.Enter)
            {
                input.Append(key.KeyChar);
                Console.Write("*");
            }
            else if (key.Key == ConsoleKey.Backspace && input.Length > 0)
            {
                input.Remove(input.Length - 1, 1);
                Console.Write("\b \b");
            }
        } while (key.Key != ConsoleKey.Enter);
        return input.ToString();
    }
}
